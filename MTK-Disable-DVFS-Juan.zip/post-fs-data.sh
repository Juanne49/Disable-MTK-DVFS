#!/system/bin/sh
# Disable Mediatek GPU DVFS
echo 0 > /sys/module/ged/parameters/gpu_dvfs_enable

# Set GPU governor to performance
echo performance > /sys/class/devfreq/13000000.mali/governor

# Force GPU min/max to 1100 MHz and keep it locked
while true; do
  echo 1100000000 > /sys/class/devfreq/13000000.mali/min_freq
  echo 1100000000 > /sys/class/devfreq/13000000.mali/max_freq
  sleep 2
done &
